"""
08_georisques.py — Risques naturels et technologiques (Géorisques)
===================================================================

Récupère, commune par commune, les risques recensés, les arrêtés de
catastrophe naturelle, le potentiel radon, le zonage sismique et
l'exposition au retrait-gonflement des argiles.

Source : API Géorisques (BRGM / ministère de la Transition écologique).

Toutes ces données sont publiées à la maille communale : aucune
agrégation douteuse ici, contrairement à l'eau potable.

Produit :
    data/mesures-risques.json   repris par 03_agregation.py

Utilisation :
    python 08_georisques.py                collecte, avec reprise
    python 08_georisques.py --tout         recollecte intégrale
    python 08_georisques.py --habillage    réapplique la présentation
    python 08_georisques.py --inspecter 38416
                                           affiche les champs bruts d'une
                                           commune, pour calibrer le script
"""

from collections import Counter
import json
import re
import sys
import time
import urllib.parse
import urllib.request
import urllib.error
from datetime import date, timedelta
from pathlib import Path

# Numéro de version du script, affiché à l'exécution : il permet
# de vérifier d'un coup d'œil que le fichier installé est le bon.
VERSION_SCRIPT = 11

DONNEES = Path("data")
REFERENTIEL = DONNEES / "referentiel-communes.json"
SORTIE = DONNEES / "mesures-risques.json"

API = "https://georisques.gouv.fr/api/v1"
SOURCE = "Géorisques — BRGM et ministère de la Transition écologique"
LICENCE = "Licence Ouverte 2.0"

VERSION = 10

RUBRIQUE = "environnement"
SOUS_RUBRIQUE = "risques"
RANGS = {"ENV-07": 5, "ENV-02": 10, "ENV-01": 20, "ENV-06": 30,
         "ENV-05": 40, "ENV-03": 50, "ENV-04": 60}
PAUSE = 0.25
DELAI = 90
TENTATIVES = 4

ANCRE_CATNAT = "catastrophes-naturelles"

# Page de référence Géorisques pour une commune. À vérifier une fois en
# ligne : l'adresse est susceptible d'évoluer, et elle est isolée ici
# pour n'avoir qu'un seul endroit à corriger.
# Géorisques n'expose pas d'adresse directe vers le dossier d'une
# commune : la consultation passe par un formulaire de recherche. Plutôt
# qu'un lien profond deviné — le précédent renvoyait une erreur 404 —
# on renvoie vers le portail, avec un libellé qui n'annonce pas un accès
# direct. Si vous relevez un jour l'adresse exacte d'un dossier communal,
# remplacez la valeur ci-dessous en y plaçant {code} à l'endroit du code
# INSEE ; le libellé s'ajustera automatiquement.
FICHE_GEORISQUES = "https://www.georisques.gouv.fr/"

# État des risques réglementaire, utile lors d'une vente ou d'une
# location. Adresse stable, indiquée sur le portail Géorisques.
ERRIAL = "https://errial.georisques.gouv.fr/#/"


def renvoi_georisques(code_commune, libelle_direct, libelle_general):
    """Lien vers Géorisques, direct si l'adresse le permet."""
    if not FICHE_GEORISQUES:
        return None
    if "{code}" in FICHE_GEORISQUES and code_commune:
        return {"url": FICHE_GEORISQUES.format(code=code_commune),
                "libelle": libelle_direct}
    return {"url": FICHE_GEORISQUES, "libelle": libelle_general}

# Les arrêtés sont identifiés par leur numéro NOR, en vigueur depuis 1987 :
# quatre lettres pour le ministère et la direction, deux chiffres d'année,
# cinq chiffres de séquence, une lettre pour la nature du texte.
# Exemple : INTE0500697A — Intérieur, 2005, arrêté.
MOTIF_NOR = re.compile(r"^[A-Z]{4}\d{7}[A-Z]$")

# Avant 1987, l'API substitue au NOR une chaîne encodant la date de
# publication au Journal officiel. Ce n'est pas un identifiant : aucun
# lien n'est possible, mais la date est récupérable.
MOTIF_SUBSTITUT = re.compile(r"^NOR(\d{4})(\d{2})(\d{2})$")

# Adresse de recherche officielle par NOR sur Légifrance.
LEGIFRANCE_NOR = (
    "https://www.legifrance.gouv.fr/search/jorf"
    "?tab_selection=jorf&query=%7B(%40ALL%5Bt%22*%22%5D)%7D"
    "&nor={nor}&isAdvancedResult=true"
    "&sortValue=SIGNATURE_DATE_DESC&pageSize=10"
    "&typeRecherche=date&init=true&page=1")

# Nombre d'arrêtés détaillés ; au-delà, seul le décompte est donné.
ARRETES_DETAILLES = 15

# Un arrêté récent est signalé en bandeau, comme une restriction
# sécheresse : c'est l'information la plus susceptible de concerner
# directement un habitant, notamment pour une déclaration d'assurance.
RECONNAISSANCE_RECENTE_MOIS = 24
ANCRE_RISQUES = "risques-recenses"

# Le potentiel radon est publié en trois catégories réglementaires.
RADON = {
    "1": ("Faible", None),
    "2": ("Faible, avec facteurs géologiques locaux", "attention"),
    "3": ("Significatif", "attention"),
}

# Le zonage sismique va de 1 (très faible) à 5 (fort).
SISMIQUE = {
    "1": ("Très faible", None),
    "2": ("Faible", None),
    "3": ("Modérée", "attention"),
    "4": ("Moyenne", "attention"),
    "5": ("Forte", "alerte"),
}


# ══════════════════════════════════════════════════════════════════
# ACCÈS À L'API
# ══════════════════════════════════════════════════════════════════

def appeler(chemin, **params):
    """Interroge Géorisques. Renvoie une liste, [] si vide, None si échec."""
    url = f"{API}/{chemin}?" + urllib.parse.urlencode(params)
    attente = 2
    for tentative in range(1, TENTATIVES + 1):
        try:
            requete = urllib.request.Request(
                url, headers={"User-Agent": "portail-territorial/1.0",
                              "Accept": "application/json"})
            with urllib.request.urlopen(requete, timeout=DELAI) as reponse:
                statut = getattr(reponse, "status", 200)
                corps = reponse.read()

            # Géorisques répond « 204 : pas de contenu » avec un corps vide
            # quand la commune n'a rien sur ce point d'entrée. Ce n'est pas
            # une erreur : c'est une absence de donnée.
            if statut == 204 or not corps.strip():
                return []
            try:
                brut = json.loads(corps.decode("utf-8"))
            except json.JSONDecodeError:
                print("[réponse illisible] ", end="", flush=True)
                return None
        except urllib.error.HTTPError as e:
            if e.code in (204, 404):
                return []
            if e.code in (429, 500, 502, 503, 504) and tentative < TENTATIVES:
                print(f"[{e.code}] ", end="", flush=True)
                time.sleep(attente)
                attente *= 2
                continue
            return None
        except (urllib.error.URLError, OSError):
            if tentative < TENTATIVES:
                print("[lenteur] ", end="", flush=True)
                time.sleep(attente)
                attente *= 2
                continue
            return None

        if isinstance(brut, list):
            return brut
        if isinstance(brut, dict):
            return brut.get("data") or brut.get("results") or []
        return []
    return None


def libelles_risques(enregistrement):
    """Intitulés des risques portés par un enregistrement.

    L'API imbrique les risques dans une liste d'objets plutôt que de les
    poser à plat : chercher au premier niveau ramenait la liste entière
    convertie en texte, ou le nom de la commune. On parcourt donc la
    structure en profondeur, en ne retenant que les champs dont le nom
    associe « libellé » et « risque ».
    """
    trouves = []

    def visiter(objet):
        if isinstance(objet, dict):
            for cle, valeur in objet.items():
                if isinstance(valeur, (dict, list)):
                    visiter(valeur)
                    continue
                nom = str(cle).lower()
                if "libelle" not in nom or "risque" not in nom:
                    continue
                texte = str(valeur or "").strip()
                if len(texte) >= 4 and not texte.isdigit():
                    trouves.append(texte)
        elif isinstance(objet, list):
            for element in objet:
                visiter(element)

    visiter(enregistrement)
    return trouves


def champ(enregistrement, *candidats):
    """Première valeur trouvée parmi plusieurs noms de champ possibles.

    Les intitulés de l'API varient d'un point d'entrée à l'autre.
    Chercher plusieurs noms évite de dépendre d'un seul.
    """
    for nom in candidats:
        valeur = enregistrement.get(nom)
        if valeur not in (None, "", []):
            return valeur
    return None


# ══════════════════════════════════════════════════════════════════
# MESURES
# ══════════════════════════════════════════════════════════════════

# Unités des indicateurs de comptage, au singulier et au pluriel.
# Centralisées ici pour que la collecte et le réhabillage accordent
# de la même façon.
UNITES = {
    "ENV-01": ("risque recensé", "risques recensés"),
    "ENV-02": ("arrêté", "arrêtés"),
    "ENV-06": ("document", "documents"),
}


def unite_de(ident, nombre):
    formes = UNITES.get(ident)
    if not formes:
        return ""
    return formes[0] if nombre <= 1 else formes[1]


def mesure(valeur, unite, nom, **habillage):
    base = {"valeur": valeur, "unite": unite, "nom": nom,
            "obtention": "natif", "source": SOURCE, "licence": LICENCE,
            "format": "texte", "niveaux": ["commune"],
            "rubrique": RUBRIQUE, "sous_rubrique": SOUS_RUBRIQUE}
    base.update(habillage)
    return base


EXPLICATIONS = {
    "ENV-01": ("Types de risques identifiés par l'État sur le territoire "
               "communal, qu'ils soient naturels ou technologiques."),
    "ENV-02": ("Depuis 1982. Un arrêté ouvre la voie à l'indemnisation des "
               "dommages par les assurances."),
    "ENV-03": ("Le radon est un gaz radioactif naturel issu du sous-sol. "
               "Son accumulation dans les bâtiments mal ventilés présente "
               "un risque pour la santé."),
    "ENV-04": ("Classement réglementaire déterminant les règles de "
               "construction parasismique applicables."),
    "ENV-05": ("Les sols argileux gonflent et se rétractent selon leur "
               "teneur en eau, ce qui peut fissurer les constructions. "
               "Les sécheresses répétées aggravent le phénomène."),
    "ENV-06": ("Documents qui délimitent les zones exposées et fixent les "
               "règles d'urbanisme et de construction qui s'y appliquent."),
    "ENV-07": ("Une reconnaissance récente ouvre la voie à l'indemnisation "
               "des dommages par les assurances. Les délais de déclaration "
               "sont courts."),
}


def habiller(ident, m):
    m["rubrique"] = RUBRIQUE
    m["sous_rubrique"] = SOUS_RUBRIQUE
    if ident in RANGS:
        m["rang"] = RANGS[ident]
    if ident in EXPLICATIONS:
        m["explication"] = EXPLICATIONS[ident]
    valeur = m.get("valeur")
    if ident in UNITES and isinstance(valeur, int):
        m["unite"] = unite_de(ident, valeur)
    return m


def sans_ancre_orpheline(mesures, blocs):
    presentes = {b.get("id") for b in (blocs or []) if b.get("id")}
    for m in mesures.values():
        if m.get("ancre") and m["ancre"] not in presentes:
            m.pop("ancre")
    return mesures


def nor_de(enregistrement):
    """Numéro NOR de l'arrêté, s'il en existe un.

    Les textes antérieurs à 1987 n'en ont pas : l'API leur substitue une
    chaîne encodant la date de publication, qui ne permet aucun lien.
    """
    for valeur in enregistrement.values():
        texte = str(valeur or "").strip().upper()
        if MOTIF_NOR.match(texte):
            return texte
    return None


def lien_arrete(enregistrement):
    """Adresse permettant de consulter l'arrêté au Journal officiel."""
    for valeur in enregistrement.values():
        texte = str(valeur or "")
        if texte.lower().startswith(("http://", "https://")):
            return texte
    nor = nor_de(enregistrement)
    return LEGIFRANCE_NOR.format(nor=nor) if nor else None


def date_substitut(enregistrement):
    """Date de publication déduite du substitut de NOR, avant 1987."""
    for valeur in enregistrement.values():
        trouve = MOTIF_SUBSTITUT.match(str(valeur or "").strip().upper())
        if trouve:
            annee, mois, jour = trouve.groups()
            try:
                return date(int(annee), int(mois), int(jour))
            except ValueError:
                return None
    return None


def lire_date(valeur):
    """Date d'un champ de l'API, quelle que soit son écriture.

    Géorisques sert ses dates en « 14/05/1988 ». Ce script ne savait
    lire que l'ISO : toute date postérieure à 1987 était donc perdue,
    et seuls les arrêtés d'avant 1987 — dont la date se déduit du
    substitut de NOR — restaient exploitables. Conséquences observées
    sur le site : « date non précisée » sur la plupart des arrêtés, une
    liste annoncée « du plus récent au plus ancien » qui ne l'était
    pas, et un bandeau de reconnaissance récente qui ne pouvait jamais
    s'afficher.

    Les deux écritures sont désormais acceptées. L'ISO d'abord : une
    date à quatre chiffres en tête n'est jamais un jour.
    """
    texte = str(valeur or "").strip()[:10]
    if not texte:
        return None
    try:
        return date.fromisoformat(texte)
    except ValueError:
        pass
    morceaux = texte.replace(".", "/").replace("-", "/").split("/")
    if len(morceaux) == 3 and len(morceaux[0]) <= 2:
        try:
            j, m, a = (int(x) for x in morceaux)
            return date(a, m, j)
        except ValueError:
            return None
    return None


def _jour(valeur):
    """Date au format français, ou None."""
    jour = lire_date(valeur)
    return jour.strftime("%d/%m/%Y") if jour else None


def date_objet(enregistrement, *fragments, exclus=()):
    """Première date exploitable parmi les champs dont le nom correspond."""
    for cle, valeur in enregistrement.items():
        nom = str(cle).lower()
        if not any(f in nom for f in fragments):
            continue
        if any(x in nom for x in exclus):
            continue
        jour = lire_date(valeur)
        if jour:
            return jour
    return None


def date_tri(enregistrement):
    """Date servant au classement chronologique, du plus récent au plus ancien.

    Le classement doit reposer sur la même détection que l'affichage,
    sans quoi un arrêté daté correctement à l'écran se retrouverait mal
    placé dans la liste.
    """
    return (date_objet(enregistrement, "debut")
            or date_objet(enregistrement, "publi", "arrete", "jo",
                          exclus=("debut", "fin"))
            or date_substitut(enregistrement)
            or date.min)


def date_dont_le_nom_contient(enregistrement, *fragments, exclus=()):
    """Première date exploitable parmi les champs dont le nom correspond.

    Les intitulés varient d'une version de l'API à l'autre. Chercher par
    fragment de nom évite de dépendre d'une orthographe exacte, et
    surtout évite qu'une date manquante passe inaperçue.
    """
    for cle, valeur in enregistrement.items():
        nom = str(cle).lower()
        if not any(f in nom for f in fragments):
            continue
        if any(x in nom for x in exclus):
            continue
        jour = _jour(valeur)
        if jour:
            return jour
    return None


def periode(enregistrement):
    """Formule décrivant la durée de l'événement."""
    debut = date_dont_le_nom_contient(enregistrement, "debut")
    fin = date_dont_le_nom_contient(enregistrement, "fin")
    if debut and fin and debut != fin:
        return f"du {debut} au {fin}"
    if debut or fin:
        return debut or fin

    # dernier recours : la date encodée dans le substitut de NOR
    substitut = date_substitut(enregistrement)
    if substitut:
        return f"publié au Journal officiel le {substitut.strftime('%d/%m/%Y')}"
    return "date non précisée"


def _annee(valeur):
    texte = str(valeur or "")[:4]
    return texte if texte.isdigit() else None


# ══════════════════════════════════════════════════════════════════

def collecter(commune):
    """Interroge les six points d'entrée pour une commune."""
    code = commune["code"]
    lon, lat = commune.get("longitude"), commune.get("latitude")

    lots = {}
    for cle, chemin, params in (
        ("risques", "gaspar/risques", {"code_insee": code}),
        ("catnat", "gaspar/catnat", {"code_insee": code, "page_size": 200}),
        ("ppr", "gaspar/ppr", {"code_insee": code, "page_size": 100}),
        ("radon", "radon", {"code_insee": code}),
        ("sismique", "zonage_sismique", {"code_insee": code}),
    ):
        lots[cle] = appeler(chemin, **params)
        time.sleep(PAUSE)

    # Le retrait-gonflement des argiles s'interroge par coordonnées.
    if lon is not None and lat is not None:
        lots["rga"] = appeler("rga", latlon=f"{lon:.5f},{lat:.5f}")
        time.sleep(PAUSE)
    else:
        lots["rga"] = []

    return lots


def synthetiser(lots, code_commune=None):
    """Construit indicateurs et blocs à partir des réponses de l'API."""
    if lots.get("risques") is None and lots.get("catnat") is None:
        return None

    # Un point d'entrée en échec ne doit pas se confondre avec une
    # absence de donnée : on retient lesquels afin de le dire.
    manquants = [cle for cle, valeur in lots.items() if valeur is None]

    risques = lots.get("risques") or []
    catnat = lots.get("catnat") or []
    ppr = lots.get("ppr") or []
    radon = lots.get("radon") or []
    sismique = lots.get("sismique") or []
    rga = lots.get("rga") or []

    mesures, blocs = {}, []

    # ── risques recensés ─────────────────────────────────────────
    # Géorisques mêle les risques et leurs déclinaisons : « Inondation »
    # côtoie « Par une crue à débordement lent de cours d'eau ». Compter
    # les deux reviendrait à compter l'inondation plusieurs fois. Les
    # déclinaisons sont donc présentées à part, comme des précisions.
    libelles, precisions = [], []
    for r in risques:
        for texte in libelles_risques(r):
            if texte.lower().startswith("par "):
                nettoye = re.sub(r"^par (une |des |le |la |les )?", "",
                                 texte, flags=re.I)
                nettoye = nettoye[:1].upper() + nettoye[1:]
                if nettoye not in precisions:
                    precisions.append(nettoye)
            elif texte not in libelles:
                libelles.append(texte)

    mesures["ENV-01"] = mesure(len(libelles),
                               unite_de("ENV-01", len(libelles)),
                               "Risques identifiés sur la commune",
                               ancre=ANCRE_RISQUES)
    if libelles:
        blocs.append({
            "rubrique": RUBRIQUE,
            "sous_rubrique": SOUS_RUBRIQUE,
            "id": ANCRE_RISQUES,
            "titre": "Risques identifiés sur la commune",
            "items": ([{"titre": lib, "details": {}}
                       for lib in sorted(libelles)]
                      + ([{"titre": "Nature des phénomènes recensés",
                           "details": {f"Type {i}": p
                                       for i, p in enumerate(
                                           sorted(precisions), start=1)}}]
                         if precisions else [])),
            "lien": renvoi_georisques(
                code_commune,
                "Consulter le rapport officiel sur Géorisques",
                "Rechercher cette commune sur Géorisques"),
            "note": ("Recensement établi par les services de l'État. La "
                     "présence d'un risque ne signifie pas que l'ensemble "
                     "de la commune y est exposé : consultez le document "
                     "d'information communal en mairie. Pour une vente ou "
                     "une location, l'état des risques réglementaire "
                     "s'établit sur ERRIAL, service gratuit de l'État."),
        })

    # ── arrêtés de catastrophe naturelle ─────────────────────────
    mesures["ENV-02"] = mesure(len(catnat),
                               unite_de("ENV-02", len(catnat)),
                               "Arrêtés de catastrophe naturelle",
                               ancre=ANCRE_CATNAT)
    if catnat:
        # Un arrêté par entrée, du plus récent au plus ancien : le
        # visiteur cherche « quand » et « pour quoi », pas un décompte.
        classes = sorted(catnat, key=date_tri, reverse=True)

        items, avec_lien = [], 0
        for a in classes[:ARRETES_DETAILLES]:
            libelle = str(champ(a, "libelle_risque_jo", "libelle_risque",
                                "libelle") or "Catastrophe naturelle")
            details = {"Événement": periode(a)}
            publication = date_dont_le_nom_contient(
                a, "publi", "arrete", "jo", exclus=("debut", "fin"))
            if publication:
                details["Arrêté publié le"] = publication

            nor = nor_de(a)
            if nor:
                details["Numéro NOR"] = nor
            else:
                reference = champ(a, "code_national_catnat", "code_national",
                                  "num_arrete")
                if reference and not MOTIF_SUBSTITUT.match(
                        str(reference).strip().upper()):
                    details["Référence"] = str(reference)

            item = {"titre": libelle, "details": details}
            adresse = lien_arrete(a)
            if adresse:
                item["lien"] = {"url": adresse,
                                "libelle": "Consulter l'arrêté sur Légifrance"}
                avec_lien += 1
            items.append(item)

        detailles_avant_resume = len(items)
        reste = len(catnat) - len(items)
        if reste > 0:
            plus_ancien = date_tri(classes[-1])
            items.append({
                "titre": f"{reste} arrêté(s) plus ancien(s)",
                "details": {"Remontant jusqu'à": (
                    plus_ancien.strftime("%Y") if plus_ancien != date.min
                    else "date inconnue")},
                "texte": "Consultables sur le portail Géorisques.",
            })

        # Le visiteur doit savoir pourquoi certains arrêtés n'ont pas de
        # lien : c'est une limite de la source, pas un oubli du site.
        detailles = detailles_avant_resume
        if avec_lien == 0:
            precision = ("Aucun de ces arrêtés ne porte de numéro NOR : "
                         "ce système d'identification n'existe que depuis "
                         "1987, et les textes antérieurs ne sont pas "
                         "consultables en ligne par ce biais.")
        elif avec_lien < detailles:
            precision = (f"{avec_lien} arrêté(s) sur {detailles} renvoient au "
                         "texte publié au Journal officiel. Les autres sont "
                         "antérieurs à 1987, année d'entrée en vigueur du "
                         "numéro NOR, et ne sont pas identifiables en ligne.")
        else:
            precision = ("Chaque arrêté renvoie au texte publié au Journal "
                         "officiel.")

        blocs.append({
            "rubrique": RUBRIQUE,
            "sous_rubrique": SOUS_RUBRIQUE,
            "id": ANCRE_CATNAT,
            "titre": "Catastrophes naturelles reconnues depuis 1982",
            "items": items,
            "lien": renvoi_georisques(
                code_commune,
                "Consulter le dossier complet sur Géorisques",
                "Rechercher cette commune sur Géorisques"),
            "note": ("Un arrêté de catastrophe naturelle ouvre la voie à "
                     "l'indemnisation des dommages par les assurances. "
                     + precision
                     + " Les données de l'API peuvent accuser un léger retard "
                       "sur le site Géorisques ; en cas d'écart, ce dernier "
                       "fait référence."),
        })

    # ── reconnaissance récente, mise en bandeau ──
    if catnat:
        recent = classes[0]
        quand = date_tri(recent)
        limite = date.today() - timedelta(days=30 * RECONNAISSANCE_RECENTE_MOIS)
        if quand != date.min and quand >= limite:
            libelle = str(champ(recent, "libelle_risque_jo", "libelle_risque",
                                "libelle") or "Catastrophe naturelle")
            mesures["ENV-07"] = mesure(
                libelle, "", "Catastrophe naturelle reconnue",
                mise_en_avant=True, ton="attention", ancre=ANCRE_CATNAT,
                repere=f"Événement {periode(recent)}",
                explication=("Une reconnaissance récente ouvre la voie à "
                             "l'indemnisation des dommages par les assurances. "
                             "Les délais de déclaration sont courts."))

    # ── potentiel radon ──────────────────────────────────────────
    if radon:
        classe = str(champ(radon[0], "classe_potentiel", "classe_potentiel_radon",
                           "classe", "potentiel") or "")
        libelle, ton = RADON.get(classe, (None, None))
        if libelle:
            mesures["ENV-03"] = mesure(libelle, "", "Potentiel radon",
                                       repere=f"Catégorie {classe} sur 3",
                                       **({"ton": ton} if ton else {}))

    # ── zonage sismique ──────────────────────────────────────────
    if sismique:
        zone = str(champ(sismique[0], "zone_sismicite", "code_zone",
                         "zonage_sismique", "libelle") or "")
        chiffre = "".join(c for c in zone if c.isdigit())[:1]
        libelle, ton = SISMIQUE.get(chiffre, (None, None))
        if libelle:
            mesures["ENV-04"] = mesure(libelle, "", "Sismicité",
                                       repere=f"Zone {chiffre} sur 5",
                                       **({"ton": ton} if ton else {}))

    # ── retrait-gonflement des argiles ───────────────────────────
    if rga:
        niveau = champ(rga[0], "exposition", "alea", "niveau_alea",
                       "codeExposition", "libelle")
        if niveau is not None:
            texte = str(niveau).capitalize()
            ton = "attention" if texte.lower().startswith(("moyen", "fort")) else None
            mesures["ENV-05"] = mesure(texte, "",
                                       "Retrait-gonflement des argiles",
                                       repere="Exposition : nulle, faible, "
                                              "moyenne ou forte",
                                       **({"ton": ton} if ton else {}))

    # ── plans de prévention ──────────────────────────────────────
    if ppr:
        mesures["ENV-06"] = mesure(len(ppr), unite_de("ENV-06", len(ppr)),
                                   "Plans de prévention des risques")

    mesures = {k: habiller(k, v) for k, v in mesures.items()}
    mesures = sans_ancre_orpheline(mesures, blocs)
    serie = chronique_catnat(catnat) if catnat else None
    resultat = {"mesures": mesures, "blocs": blocs}
    if serie:
        resultat["chroniques"] = [serie]
    if manquants:
        resultat["_incomplet"] = manquants
    return resultat


# ══════════════════════════════════════════════════════════════════


# ══════════════════════════════════════════════════════════════════
# SÉRIE HISTORIQUE — arrêtés par décennie
#
# Les arrêtés sont déjà collectés ; seule leur répartition dans le
# temps ne l'était pas. Groupés par décennie, ils montrent une chose
# qu'aucun compteur ne montre : la fréquence des reconnaissances a
# changé.
#
# **La décennie, et pas l'année.** Une commune connaît zéro, un ou
# deux arrêtés par an ; une courbe annuelle serait un hérisson de
# barres à zéro d'où l'on ne tirerait rien. La décennie lisse ce bruit
# sans effacer la tendance.
#
# **La dernière décennie est incomplète, et c'est écrit.** Comparer
# 2020-2026, sept années, à 1990-1999, dix années, ferait croire à une
# baisse là où il n'y a qu'un décompte plus court. La note le dit, et
# l'étiquette de la dernière barre porte ses années réelles.
# ══════════════════════════════════════════════════════════════════

DEBUT_CATNAT = 1982        # première année du dispositif


def chronique_catnat(catnat, aujourdhui=None):
    """Nombre d'arrêtés par décennie, du plus ancien au plus récent."""
    aujourdhui = aujourdhui or date.today()
    dates = [d for d in (date_tri(a) for a in catnat) if d != date.min]
    if len(dates) < 3:
        return None                # trop peu pour qu'une répartition dise quoi que ce soit

    premiere = (min(min(d.year for d in dates), DEBUT_CATNAT) // 10) * 10
    derniere = (aujourdhui.year // 10) * 10

    etiquettes, valeurs = [], []
    for debut in range(premiere, derniere + 1, 10):
        fin = min(debut + 9, aujourdhui.year)
        valeurs.append(sum(1 for d in dates if debut <= d.year <= fin))
        etiquettes.append(f"{debut}-{str(fin)[-2:]}" if fin != debut + 9
                          else f"{debut}s")

    # Un événement national reconnu pour presque toutes les communes le
    # même jour — la tempête de novembre 1982 en est le cas d'école —
    # gonfle une décennie entière et fait lire une « baisse » là où il
    # n'y a qu'un épisode exceptionnel au départ du dispositif. Quand
    # une seule date fait plus du tiers d'une période, elle est nommée.
    domination = None
    for debut in range(premiere, derniere + 1, 10):
        fin = min(debut + 9, aujourdhui.year)
        dedans = [d for d in dates if debut <= d.year <= fin]
        if len(dedans) < 5:
            continue
        jour, combien = max(
            ((j, dedans.count(j)) for j in set(dedans)), key=lambda x: x[1])
        if combien * 3 > len(dedans):
            domination = (jour, combien, len(dedans), debut, fin)
            break

    incomplete = (aujourdhui.year % 10) != 9
    return {
        "id": "catnat-decennies",
        "rubrique": RUBRIQUE, "sous_rubrique": SOUS_RUBRIQUE,
        "forme": "barres", "rang": 10,
        "titre": "Arrêtés de catastrophe naturelle, par décennie",
        "source": f"{SOURCE} · depuis {DEBUT_CATNAT}",
        "unite": "arrêtés", "decimales": 0,
        "etiquettes": etiquettes, "valeurs": valeurs,
        "agregation": "somme",
        "note": ("Le dispositif existe depuis 1982."
                 + (f" La dernière période ne compte que "
                    f"{aujourdhui.year - derniere + 1} année(s) : elle n'est "
                    f"pas comparable telle quelle aux décennies pleines."
                    if incomplete else "")
                 + (f" Attention à la lecture : sur {domination[3]}-"
                    f"{str(domination[4])[-2:]}, {domination[1]} des "
                    f"{domination[2]} arrêtés relèvent d'un seul événement, "
                    f"reconnu le {domination[0].strftime('%d/%m/%Y')}. Une "
                    f"période dominée par un épisode unique ne se compare "
                    f"pas aux autres."
                    if domination else "")),
    }


def inspecter(code):
    """Affiche les champs bruts renvoyés pour une commune."""
    print(f"\nInspection de la commune {code}")
    print("─" * 46)
    for cle, chemin, params in (
        ("risques", "gaspar/risques", {"code_insee": code}),
        ("catnat", "gaspar/catnat", {"code_insee": code, "page_size": 3}),
        ("ppr", "gaspar/ppr", {"code_insee": code, "page_size": 3}),
        ("radon", "radon", {"code_insee": code}),
        ("sismique", "zonage_sismique", {"code_insee": code}),
    ):
        lot = appeler(chemin, **params)
        print(f"\n  ── {cle} ──")
        if lot is None:
            print("     échec de l'appel")
        elif not lot:
            print("     aucune donnée")
        else:
            print(f"     {len(lot)} enregistrement(s), champs du premier :")
            for k, v in lot[0].items():
                print(f"       {k:<34} {str(v)[:60]}")
            if cle == "catnat":
                print(f"     → NOR détecté      : {nor_de(lot[0]) or 'aucun'}")
                print(f"     → date d'événement : "
                      f"{periode(lot[0])}")
                adresse = lien_arrete(lot[0])
                print(f"     → lien             : {adresse or 'aucun'}")
        time.sleep(PAUSE)
    print()


def rehabiller(silencieux=False):
    if not SORTIE.exists():
        print(f"\n[ERREUR] {SORTIE} introuvable.")
        sys.exit(1)
    contenu = json.loads(SORTIE.read_text(encoding="utf-8"))
    for bloc in contenu.get("communes", {}).values():
        bloc["mesures"] = {k: habiller(k, v)
                           for k, v in bloc.get("mesures", {}).items()}
        bloc["mesures"] = sans_ancre_orpheline(bloc["mesures"],
                                               bloc.get("blocs"))
    contenu["version"] = VERSION
    SORTIE.write_text(json.dumps(contenu, ensure_ascii=False, indent=1),
                      encoding="utf-8")
    message = f"  {len(contenu.get('communes', {}))} commune(s) remises au format courant."
    print(message if silencieux else f"\nRéhabillage — Géorisques\n{'─' * 46}\n{message}\n")


def main():
    if "--inspecter" in sys.argv:
        i = sys.argv.index("--inspecter")
        if i + 1 >= len(sys.argv):
            print("\n  Précisez un code INSEE : python 08_georisques.py "
                  "--inspecter 38416\n")
            sys.exit(1)
        inspecter(sys.argv[i + 1])
        return

    if "--habillage" in sys.argv:
        rehabiller()
        return

    print("\nRisques naturels et technologiques — Géorisques")
    print("─" * 46)
    print(f"  version {VERSION_SCRIPT} du script")

    if not REFERENTIEL.exists():
        print(f"\n[ERREUR] {REFERENTIEL} introuvable.")
        print("  Lancez d'abord 01_referentiel.py et 02_canton.py")
        sys.exit(1)

    reprise = "--tout" not in sys.argv
    if reprise and SORTIE.exists():
        precedent = json.loads(SORTIE.read_text(encoding="utf-8"))
        if precedent.get("version") != VERSION:
            print("  Collecte précédente à un format antérieur : "
                  "réhabillage automatique.")
            rehabiller(silencieux=True)

    acquis = {}
    if reprise and SORTIE.exists():
        acquis = json.loads(SORTIE.read_text(encoding="utf-8")).get("communes", {})
        if acquis:
            print(f"  Reprise : {len(acquis)} commune(s) déjà collectée(s).\n")

    communes = json.loads(REFERENTIEL.read_text(encoding="utf-8"))["communes"]
    resultat = dict(acquis)
    en_erreur, sans_donnee = [], []

    def sauver():
        DONNEES.mkdir(exist_ok=True)
        SORTIE.write_text(json.dumps({
            "genere_le": date.today().isoformat(),
            "version": VERSION,
            "source": SOURCE, "licence": LICENCE, "frequence": "trimestrielle",
            "communes": {code: {c: v for c, v in bloc.items()
                                if not c.startswith("_")}
                         for code, bloc in resultat.items()},
        }, ensure_ascii=False, indent=1), encoding="utf-8")

    for i, c in enumerate(communes, start=1):
        if c["code"] in acquis:
            continue
        print(f"  [{i:>2}/{len(communes)}] {c['nom'][:30]:<30}", end=" ", flush=True)

        try:
            synthese = synthetiser(collecter(c), c["code"])
        except Exception as erreur:
            en_erreur.append(f"{c['nom']} ({type(erreur).__name__}: {erreur})")
            print("erreur de traitement")
            continue

        if not synthese:
            sans_donnee.append(c["nom"])
            print("aucune donnée")
            continue

        resultat[c["code"]] = synthese
        sauver()
        m = synthese["mesures"]
        reserve = (f"  [incomplet : {', '.join(synthese['_incomplet'])}]"
                   if synthese.get("_incomplet") else "")
        print(f"{m['ENV-01']['valeur']} risque(s), "
              f"{m['ENV-02']['valeur']} arrêté(s) CatNat{reserve}")

    sauver()

    # Les libellés étant reconnus par motif, il faut pouvoir vérifier
    # d'un coup d'œil que ce sont bien des risques et non un champ
    # attrapé par erreur.
    vus = Counter()
    for bloc in resultat.values():
        for b in bloc.get("blocs", []):
            if b.get("id") == ANCRE_RISQUES:
                for item in b["items"]:
                    vus[item["titre"]] += 1
    if vus:
        print(f"\n  Risques reconnus :")
        for libelle, nombre in vus.most_common(12):
            print(f"    {nombre:>3} commune(s)   {libelle[:56]}")
        print(f"    {len(vus)} libellé(s) distinct(s) au total.")

    print(f"\n  Communes renseignées : {len(resultat)}/{len(communes)}")
    if resultat:
        total = sum(v["mesures"]["ENV-02"]["valeur"] for v in resultat.values()
                    if "ENV-02" in v["mesures"])
        print(f"  Arrêtés CatNat cumulés : {total}")
    if sans_donnee:
        print(f"  Sans donnée ({len(sans_donnee)}) : {', '.join(sans_donnee[:6])}")
    if en_erreur:
        print(f"  [attention] En erreur ({len(en_erreur)}) :")
        for ligne in en_erreur[:6]:
            print(f"    · {ligne}")
    print(f"  Fichier : {SORTIE}\n")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n  Interrompu. Relancez pour continuer :  "
              "python 08_georisques.py\n")
        sys.exit(130)
